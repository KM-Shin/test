/**
 * Polyfills etc. for legacy browsers (pre ES2015/ES6)
 */

// Import polyfills and shims
import 'airbnb-browser-shims';
